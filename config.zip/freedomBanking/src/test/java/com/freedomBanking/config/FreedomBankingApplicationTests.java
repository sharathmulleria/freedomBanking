package com.freedomBanking.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreedomBankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
