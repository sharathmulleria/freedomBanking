package com.freedomBanking.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreedomBankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreedomBankingApplication.class, args);
	}

}
